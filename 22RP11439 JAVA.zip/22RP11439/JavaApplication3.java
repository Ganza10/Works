/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication3;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    String color= "Yellow";
    if (color=="Yellow") {
        System.out.println("The color is Yellow");
    }else{
        System.out.println("color is not Yellow");
    }
    System.out.println("\n");
    Scanner y=new Scanner (System.in);
    System.out.println ("enter the angle b");
    int base=y.nextInt();
    System.out.println ("enter the angle h");
    int height=y.nextInt ();
    System.out.println("enter the angle hy");
    int hypothenus=y.nextInt();
     int sum=base+height+hypothenus;
     System.out.println("the sum =+sum");
     if (sum==180){
     System.out.println("the triangle is valid");
    }
     else{
      System.out.println("the triangle is not valid");
     }
    System.out.println("\n");
    Scanner a=new Scanner (System.in);
    System.out.println("enter the fisrt subject marks");
    int biology=a.nextInt();
    System.out.println("enter the second subject marks");
    int maths=a.nextInt();
    System.out.println("enter the third subject marks");
    int english=a.nextInt();
    int add=biology+maths+english;
    System.out.println("sum="+sum);
    float average=sum/3;
    System.out.println("average="+average);
    if (average>=50){
        System.out.println("You have GRADE A");
    }else{
        System.out.println("You have to REPEAT");
    }
    
    System.out.println("\n");
    
    
    }}
